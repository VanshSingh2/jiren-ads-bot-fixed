import os

# =============================================================================
# Jiren Ads Bot – Configuration
# ALL secrets MUST come from environment variables (or a .env file loaded by
# python-dotenv / Docker). Never commit real tokens, passwords or keys.
# =============================================================================

# Project root (directory containing this config.py) — local media lives in assets/
_CONFIG_DIR = os.path.dirname(os.path.abspath(__file__))
_ASSETS_DIR = os.path.join(_CONFIG_DIR, 'assets')

def _env(key: str, default: str = '') -> str:
    return os.getenv(key, default).strip()

def _env_int(key: str, default: int = 0) -> int:
    try:
        return int(os.getenv(key, str(default)))
    except (TypeError, ValueError):
        return default

def _media_path(env_key: str, local_filename: str) -> str:
    """Prefer env URL/path; else assets/<local_filename> if present on disk."""
    val = _env(env_key, '')
    if val:
        if val.startswith(('http://', 'https://', '/')):
            return val
        candidate = os.path.join(_CONFIG_DIR, val)
        if os.path.isfile(candidate):
            return candidate
        return val
    local = os.path.join(_ASSETS_DIR, local_filename)
    if os.path.isfile(local):
        return local
    return ''

BOT_CONFIG = {
    # Telegram API (https://my.telegram.org)
    'api_id': _env_int('TELEGRAM_API_ID', 0),
    'api_hash': _env('TELEGRAM_API_HASH', ''),

    # Main bot
    'bot_token': _env('BOT_TOKEN', ''),
    'owner_id': _env_int('OWNER_ID', 0),

    # MongoDB
    'mongo_uri': _env('MONGO_URI', ''),
    'db_name': _env('MONGO_DB_NAME', 'gokuads_db'),

    # Logger bot (optional – used for detailed send logs)
    'logger_bot_token': _env('LOGGER_BOT_TOKEN', ''),
    'logger_bot_username': _env('LOGGER_BOT_USERNAME', ''),

    # Admin notification bot + channel (optional)
    'notification_bot_token': _env('NOTIFICATION_BOT_TOKEN', ''),
    'notification_channel_id': _env_int('NOTIFICATION_CHANNEL_ID', 0),
}

# Fail fast if critical secrets are missing (the bot also checks this at startup)
_REQUIRED = ['api_id', 'api_hash', 'bot_token', 'owner_id', 'mongo_uri']
_missing = [k for k in _REQUIRED if not BOT_CONFIG.get(k)]
if _missing and os.getenv('SKIP_CONFIG_CHECK', '').lower() not in ('1', 'true', 'yes'):
    # Only warn here – full exit happens inside bot.py so manager can still start
    import sys
    print(f"[CONFIG] WARNING: missing required env vars: {', '.join(k.upper() for k in _missing)}", file=sys.stderr)

# ===================== PLAN TIERS =====================
# Starter (₹199), Pro (₹299), Elite (₹399)

PLAN_SCOUT = {
    'name': 'Legacy',
    'price': 0,
    'price_display': 'N/A',
    'tagline': 'Legacy plan (disabled)',
    'emoji': '🔰',
    'max_accounts': 0,
    'msg_delay': 60,
    'round_delay': 900,
    'auto_reply_enabled': False,
    'max_topics': 2,
    'max_groups_per_topic': 10,
    'max_auto_groups': 0,
    'max_groups_per_round': 0,
    'logs_enabled': False,
    'description': 'Legacy plan (disabled)',
}

PLAN_GROW = {
    'name': 'Starter',
    'price': 199,
    'price_display': '₹199',
    'tagline': 'Scale your reach with multiple accounts',
    'emoji': '📈',
    'max_accounts': 2,
    'msg_delay': 30,
    'round_delay': 600,
    'auto_reply_enabled': True,
    'max_topics': 5,
    'max_groups_per_topic': 50,
    'max_auto_groups': 100,
    'max_groups_per_round': 100,
    'logs_enabled': True,
    'description': '2 accounts, medium delays (30s/600s), auto-reply + logs + 🔄 Smart Rotation + 👥 Auto Group Join',
}

PLAN_PRIME = {
    'name': 'Pro',
    'price': 299,
    'price_display': '₹299',
    'tagline': 'Advanced automation for serious marketers',
    'emoji': '⭐',
    'max_accounts': 3,
    'msg_delay': 10,
    'round_delay': 120,
    'auto_reply_enabled': True,
    'max_topics': 9,
    'max_groups_per_topic': 100,
    'max_auto_groups': 150,
    'max_groups_per_round': 150,
    'logs_enabled': True,
    'description': '3 accounts, fast delays (10s/120s), full features + 🔄 Smart Rotation + 👥 Auto Group Join',
}

PLAN_DOMINION = {
    'name': 'Elite',
    'price': 399,
    'price_display': '₹399',
    'tagline': 'Ultimate power for advertising domination',
    'emoji': '👑',
    'max_accounts': 4,
    'msg_delay': 10,
    'round_delay': 120,
    'auto_reply_enabled': True,
    'max_topics': 15,
    'max_groups_per_topic': 200,
    'max_auto_groups': 200,
    'max_groups_per_round': 200,
    'logs_enabled': True,
    'description': '4 accounts, fastest delays (10s/120s), priority support + 🔄 Smart Rotation + 👥 Auto Group Join',
}

PLANS = {
    'scout': PLAN_SCOUT,
    'grow': PLAN_GROW,
    'prime': PLAN_PRIME,
    'dominion': PLAN_DOMINION,
}

# Backwards compat
FREE_TIER = PLAN_SCOUT.copy()
PREMIUM_TIER = PLAN_DOMINION.copy()
ADMIN_USERNAME = _env('ADMIN_USERNAME', 'admin')

MESSAGES = {
    'welcome': "Welcome to Jiren Ads Bot\n\nAutomate Telegram promotions across groups and topics with clean controls and stable delivery.\n\nTap Launch Ads to get started.",
    # Local default: assets/welcome.jpg (Jiren art). Override with WELCOME_IMAGE=url or path.
    'welcome_image': _media_path('WELCOME_IMAGE', 'welcome.jpg'),

    # Applied to ALL added accounts when user opens dashboard (/start).
    'account_last_name_tag': '',
    'account_bio': '',
    'support_link': _env('SUPPORT_LINK', 'https://t.me/'),
    'updates_link': _env('UPDATES_LINK', 'https://t.me/'),
    'premium_contact': "Contact admin to purchase access.\n\nPaid Plan Benefits:\n- More accounts\n- Faster delays\n- Auto reply\n- Detailed logs\n- Priority support",
    'tos_risk_notice': (
        "<b>Important</b>\n\n"
        "Automated multi-account advertising can violate Telegram Terms of Service.\n"
        "Accounts may receive FloodWait limits or permanent bans. "
        "Use at your own risk; the operators are not responsible for banned accounts."
    ),

    'privacy_short': (
        "<b>Privacy & Terms</b>\n\n"
        "<blockquote>By using Jiren Ads Bot, you agree to responsible usage and Telegram ToS.\n"
        "We store only session data needed to run automation.\n"
        "No data is sold or shared.</blockquote>"
    ),
    'privacy_full_link': _env('PRIVACY_URL', ''),
}

# ===================== Force Join =====================
FORCE_JOIN = {
    'enabled': _env('FORCE_JOIN_ENABLED', 'true').lower() in ('1', 'true', 'yes', 'on'),
    'channel_username': _env('FORCE_JOIN_CHANNEL', ''),
    # Optional; defaults to same welcome art if FORCE_JOIN_IMAGE unset
    'image_url': _media_path('FORCE_JOIN_IMAGE', 'welcome.jpg'),
    'message': _env(
        'FORCE_JOIN_MESSAGE',
        "**Access locked**\n\nJoin our **Channel** to continue.\nAfter joining, tap **Verify**."
    ),
}

PLAN_IMAGES = {
    # Optional plan art; fall back to welcome.jpg so dashboard/plan screens stay branded
    'grow': _media_path('GROW_PLAN_IMAGE', 'welcome.jpg'),
    'prime': _media_path('PRIME_PLAN_IMAGE', 'welcome.jpg'),
    'dominion': _media_path('DOMINION_PLAN_IMAGE', 'welcome.jpg'),
}

# ===================== Payment Config =====================
UPI_PAYMENT = {
    # Local default: assets/upi_qr.jpg — override with UPI_QR_IMAGE_URL=url or path
    'qr_image_url': _media_path('UPI_QR_IMAGE_URL', 'upi_qr.jpg'),
    'upi_id': _env('UPI_ID', ''),
    'payee_name': _env('UPI_PAYEE_NAME', ''),
}

INTERVAL_PRESETS = {
    'slow': {'msg_delay': 60, 'round_delay': 900, 'name': 'Slow (Safe)'},
    'medium': {'msg_delay': 30, 'round_delay': 600, 'name': 'Medium (Balanced)'},
    'fast': {'msg_delay': 10, 'round_delay': 300, 'name': 'Fast (Risky)'},
}

TOPICS = ['instagram', 'exchange', 'twitter', 'telegram', 'minecraft', 'tiktok', 'youtube', 'whatsapp', 'other']

# Proxies: prefer PROXY_LIST env (one host:port:user:pass per line or semicolon-separated).
# config.PROXIES is kept for backward compatibility and is merged by the manager.
PROXIES = []
