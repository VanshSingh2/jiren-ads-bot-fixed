"""Simple in-memory rate limiter for bot UI commands/callbacks."""
from __future__ import annotations
import time
from collections import defaultdict
from threading import Lock

_lock = Lock()
_hits = defaultdict(list)  # key -> list[monotonic ts]


def allow(key: str, max_hits: int = 20, window_sec: float = 60.0) -> bool:
    """Return True if under limit; also records this hit when allowed."""
    now = time.monotonic()
    with _lock:
        lst = _hits[key]
        cutoff = now - window_sec
        lst[:] = [t for t in lst if t >= cutoff]
        if len(lst) >= max_hits:
            return False
        lst.append(now)
        return True


def allow_user(user_id, action: str = "cb", max_hits: int = 30, window_sec: float = 60.0) -> bool:
    return allow(f"{action}:{user_id}", max_hits=max_hits, window_sec=window_sec)
