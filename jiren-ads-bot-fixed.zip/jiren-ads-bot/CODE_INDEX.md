# Jiren Ads Bot — Code Index

Quick map of every major module, collection, handler, and hot path so you can
find anything fast. Line numbers refer to `bot.py` after the async-safety pass
(approximate; search by symbol name if they drift).

---

## Project layout

| File | Role |
|------|------|
| `bot.py` | Main application (UI bot + worker forwarding) |
| `manager.py` | Auto-scaling process supervisor (spawn/kill workers) |
| `config.py` | Plans, messages, force-join, UPI — **env-only secrets** |
| `load_test.py` | Capacity simulation 200–500 users (no Telegram) |
| `proxy_health.py` | Proxy liveness + blacklist |
| `logging_utils.py` | Structured logging helpers |
| `click-tracker.workflow.json` | n8n click redirect |
| `group-discovery.workflow.json` | n8n group discovery |
| `docker-compose.yml` | Mongo + bot single-box deploy |
| `.env.example` | All env vars |
| `CAPACITY.md` / `SECURITY.md` / `PERFORMANCE.md` | Ops docs |

---

## bot.py — section map

| Region | Topic |
|--------|--------|
| Top | Imports, `CONFIG`, encryption, Mongo client + **collections** |
| `ensure_indexes` | All Mongo indexes |
| Caches | `_user_cache`, `_admin_cache`, `_accounts_cache`, `_logs_chat_cache` |
| `db_call` / `_DB_EXECUTOR` | **Required** for any Mongo from async code |
| `get_user` / `is_admin` / `is_premium` / `get_user_accounts` | Sync helpers (call via `await db_call(...)`) |
| Force-join | `_forcejoin_*`, `enforce_forcejoin_or_prompt` |
| Broadcast control | `start_broadcast_for_user`, `stop_broadcast_for_user` |
| Account CRUD | `delete_account_and_related`, settings/stats helpers |
| Toxic groups / flood waits | strike + prune helpers |
| Click tracking helpers | code generation for tracked links |
| Proxies / sharding | `make_account_client`, `_owns_account`, `NODE_*`, `WORKER_*` |
| **`run_forwarding_loop`** | Per-account send loop (workers) |
| Reconciliation | desired-state engine — keeps tasks matched to `is_forwarding` |
| UI helpers / keyboards | dashboard text, plan keyboards |
| **Handlers** | `/start`, commands, **giant `callback`**, admin tools |
| Notifications | admin channel alerts |
| Ops manager | `/health`, chat ops |
| `main()` | role split UI vs worker, indexes, pools |

---

## Mongo collections

| Collection | Purpose | Key indexes |
|------------|---------|-------------|
| `users` | Profiles, plans, settings | `user_id` unique, `username`, `created_at` |
| `accounts` | Sessions, `is_forwarding` | `owner_id`, `(is_forwarding, owner_id)` |
| `account_topics` | Topic targets | `(account_id, topic)` |
| `account_auto_groups` | Auto-join groups | `(account_id, group_id)` |
| `account_settings` | Per-account config | `account_id` unique |
| `account_stats` | Sent/failed counters | `account_id` unique |
| `account_failed_groups` | Soft-fail tracking | `(account_id, group_key)` |
| `account_flood_waits` | Flood backoff | `(account_id, group_key)`, `wait_until` |
| `toxic_groups` | Auto-prune strikes | `(account_id, group_key)` unique |
| `click_links` | Tracked ad links | `code` unique, `user_id` |
| `discovered_groups` | n8n discovery | `username`, `niche` |
| `admins` | Extra admins | `user_id` unique |
| `bot_settings` | Global + ops overrides | `_id: global` |
| `worker_health` | Manager adaptive scaling | `updated_at` |
| `logger_tokens` | Log channel tokens | `token` unique |
| `manager_status` | Per-node status (manager) | `_id: node:N` |

---

## Async safety rules (mandatory)

```python
# BAD — freezes the event loop under concurrent users
user = get_user(uid)
is_admin(uid)
accounts_col.find_one(...)

# GOOD — runs on dedicated DB thread pool
user = await db_call(get_user, uid)
await db_call(is_admin, uid)
await db_call(accounts_col.find_one, {'_id': ...})

# GOOD — multi-statement batch
def _work():
    a = users_col.find_one(...)
    accounts_col.update_one(...)
    return a
result = await db_call(_work)
```

Sync helpers (`get_user`, `is_admin`, …) are **intentionally sync** so they can
run inside `db_call` threads and inside other sync helpers. Never call them
directly from `async def` without `await db_call`.

---

## Event handlers (Telegram UI)

| Pattern / data | Function | Notes |
|----------------|----------|-------|
| `/start` | `cmd_start` | Uses `db_call` for user/admin |
| `/startbroadcast` `/stopbroadcast` | | |
| `/ban` `/rmprm` `/users` `/clearusers` | admin | |
| `/mystats` `/list` `/logmode` `/upgrade` | user | |
| `/freq` `/frequency` | admin frequency | |
| `/health` `/manager` | ops | |
| `/starter` `/pro` `/elite` (+ aliases) | grant plan | |
| `/addacc` `/addaccount` `/removeacc` | admin accounts | |
| **All inline buttons** | `callback` | Answers immediately, then `db_call` |
| Admin account mgmt | `admin_*` callbacks | devices, OTP |

---

## Worker / send path

```
manager.py
  └─ bot.py BOT_ROLE=worker
        └─ reconciler → ensure_account_running
              └─ run_forwarding_loop(user_id, account_id)
                    ├─ connect Telethon client
                    ├─ load groups (topics / auto) via db_call
                    ├─ for each group: send + msg_delay
                    └─ round_delay → next round
```

UI process (`BOT_ROLE=bot`) **does not forward**. That split is what keeps the
dashboard responsive at 500 users.

---

## manager.py symbols

| Symbol | Purpose |
|--------|---------|
| `_desired_workers` | `ceil(active / cap)` clamped |
| `_set_worker_count` | Restart worker pool with coordinated WORKER_COUNT |
| `_adapt_cap` | Shrink/grow accounts-per-worker from health docs |
| `_check_proxies` / `_capacity_advisor` | Admin DMs |
| `_apply_overrides` | Live ops settings from `bot_settings` |
| `_write_status` | Publishes node state for `/health` |

---

## Env vars (performance)

| Var | Default | Meaning |
|-----|---------|---------|
| `DB_THREAD_POOL` | 128 | Dedicated Mongo thread pool |
| `ASYNC_DEFAULT_POOL` | 64 | Other `to_thread` work |
| `USER_CACHE_TTL` | 15 | User doc cache seconds |
| `ACCOUNTS_CACHE_TTL` | 10 | Account list cache |
| `ADMIN_CACHE_TTL` | 60 | Admin flag cache |
| `DISABLE_TEXT_STYLE` | 0 | Set `1` to cut CPU on sends |
| `BOT_ROLE` | all | `bot` \| `worker` \| `all` |

---

## Finding things fast

```bash
# Handlers
rg -n '@main_bot.on' bot.py

# Mongo usage
rg -n '_col\.(find|update|delete)' bot.py

# Async DB offload
rg -n 'await db_call' bot.py

# Forwarding
rg -n 'run_forwarding_loop|is_forwarding' bot.py

# Plans / limits
rg -n 'PLAN_|max_accounts|msg_delay' config.py bot.py
```
