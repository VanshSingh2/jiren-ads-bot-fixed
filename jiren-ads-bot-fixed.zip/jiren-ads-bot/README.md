# Jiren Ads Bot

Telegram multi-account ad forwarding bot with manager-driven workers, per-user cycle interval, and frequency as a max cap only.

## Quick start (VPS)

See **DEPLOY.md** for full systemd + env setup.

```bash
cd /opt/jiren-ads-bot
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env   # edit with real values
mkdir -p session
python manager.py      # production (UI + auto workers)
```

## Roles

| `BOT_ROLE` | Meaning |
|------------|---------|
| `bot` | UI only |
| `worker` | Forwarding only |
| `all` | Both in one process (dev / small scale) |

Production: always run **`python manager.py`** (spawns `bot` + `worker` children).

## Important env

- `ENCRYPTION_KEY` — generate once, never change (sessions depend on it)
- `MONGO_URI` — required
- `DISABLE_TEXT_STYLE=1` — recommended at scale
- `LIVE_SEND_LOGS=0` — recommended at scale
