# Performance — Zero UI / DB lag at 500+ users

## Root cause of lag (fixed)

The bot uses **synchronous pymongo**. Any `users_col.find_one(...)` or `get_user()` called **directly inside an async handler** blocks the entire asyncio event loop → every other user waits.

### Fixes applied

1. **`/start` and every `CallbackQuery`** now use `await db_call(is_admin, …)` / `await db_call(get_user, …)` so Mongo never runs on the event loop.
2. **Callbacks answer immediately** (`await event.answer()`) before any DB work → Telegram UI feels instant.
3. **Dedicated DB thread pool** (`DB_THREAD_POOL=128`) separate from the default asyncio executor so UI and workers do not starve each other.
4. **Longer caches** (defaults): user 15s, admin 60s, accounts 10s, logs 30s.
5. **Account-list cache** for dashboard / menu paths.
6. **Forwarding round flags batched** into one thread-pool hop (was 4 serial awaits).
7. **`DISABLE_TEXT_STYLE=1`** recommended — Unicode stylizing on every send burns CPU.

## Intentional send delays ≠ lag

Plan delays (`msg_delay` 10–30s, `round_delay` 120–600s) are **anti-ban pacing**. They are not bugs. Removing them increases FloodWait / PeerFlood / bans.

“No lag” means:
- Button taps respond in <200 ms
- DB does not block the event loop
- Workers schedule the next send as soon as the delay expires (no extra queue delay)

It does **not** mean “send as fast as possible to every group”.

## Required production layout (critical)

```bash
# Use the manager — UI bot and workers are SEPARATE processes
python manager.py
```

| Process | Role | Does it forward? |
|---------|------|------------------|
| `BOT_ROLE=bot` | UI only | No |
| `BOT_ROLE=worker` | Sends only | Yes |

Never run `BOT_ROLE=all` with hundreds of accounts — UI and sending share one event loop and will lag.

## Env knobs

```bash
USER_CACHE_TTL=15
ADMIN_CACHE_TTL=60
ACCOUNTS_CACHE_TTL=10
DB_THREAD_POOL=128        # raise to 256 on 8+ vCPU if Mongo is remote
ASYNC_DEFAULT_POOL=64
DISABLE_TEXT_STYLE=1
LIVE_SEND_LOGS=0          # keep off at scale
MONGO_MAX_POOL=100        # per process
```

## Mongo latency

If Atlas is in another region, every `db_call` pays RTT. Prefer:
- Same-region Atlas, or
- Self-hosted Mongo on the same VPS (`docker-compose`)

Check: `python load_test.py --users 500 --real-mongo`

## Remaining sync calls

Some rarely used admin paths still call pymongo synchronously. Under normal user traffic they are not on the hot path. When editing handlers, rule of thumb:

```python
# BAD — freezes UI for everyone
user = get_user(uid)

# GOOD
user = await db_call(get_user, uid)
```
