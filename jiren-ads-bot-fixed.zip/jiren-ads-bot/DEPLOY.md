# Deploy on a VPS (systemd)

## 1. Server prep (Ubuntu 22.04+)

```bash
sudo apt update && sudo apt install -y python3 python3-venv python3-pip git
sudo useradd -r -m -d /opt/jiren-ads-bot -s /bin/bash jiren || true
sudo mkdir -p /opt/jiren-ads-bot
sudo chown -R jiren:jiren /opt/jiren-ads-bot
```

## 2. Upload code

From your laptop (after cloning / unzipping):

```bash
# example: scp the folder
scp -r jiren-ads-bot/* user@YOUR_VPS_IP:/tmp/jiren-upload/
# on VPS:
sudo rsync -a /tmp/jiren-upload/ /opt/jiren-ads-bot/
sudo chown -R jiren:jiren /opt/jiren-ads-bot
```

Or `git clone` your private repo into `/opt/jiren-ads-bot`.

## 3. Python env + dependencies

```bash
sudo -u jiren -H bash -lc '
  cd /opt/jiren-ads-bot
  python3 -m venv .venv
  .venv/bin/pip install -U pip
  .venv/bin/pip install -r requirements.txt
  mkdir -p session
'
```

## 4. Environment file

```bash
sudo -u jiren cp /opt/jiren-ads-bot/.env.example /opt/jiren-ads-bot/.env
sudo -u jiren nano /opt/jiren-ads-bot/.env
```

Required at minimum:

```env
TELEGRAM_API_ID=...
TELEGRAM_API_HASH=...
BOT_TOKEN=...
OWNER_ID=...
MONGO_URI=mongodb+srv://...   # or local mongo
MONGO_DB_NAME=gokuads_db
ENCRYPTION_KEY=...            # generate once:
# python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"
DISABLE_TEXT_STYLE=1
LIVE_SEND_LOGS=0
```

Secure the file:

```bash
sudo chmod 600 /opt/jiren-ads-bot/.env
```

## 5. MongoDB

**Option A – MongoDB Atlas** (easiest): put the connection string in `MONGO_URI`.

**Option B – Docker Compose** (self-hosted mongo + bot):

```bash
cd /opt/jiren-ads-bot
# set MONGO_ROOT_USER / MONGO_ROOT_PASS and:
# MONGO_URI=mongodb://USER:PASS@mongo:27017/gokuads_db?authSource=admin
sudo docker compose up -d --build
```

**Option C – system Mongo** on the VPS (install `mongodb-org` yourself and point `MONGO_URI` at `localhost`).

## 6. systemd (continuous run)

```bash
sudo cp /opt/jiren-ads-bot/deploy/jiren-ads.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable jiren-ads
sudo systemctl start jiren-ads
sudo systemctl status jiren-ads
```

Logs:

```bash
journalctl -u jiren-ads -f
```

Restart after code/.env change:

```bash
sudo systemctl restart jiren-ads
```

Stop:

```bash
sudo systemctl stop jiren-ads
```

## 7. Verify

1. Open your bot in Telegram → `/start`
2. `journalctl -u jiren-ads -n 50` should show manager + workers
3. Add a test account and start broadcast

## Notes

- Prefer **manager.py** over `BOT_ROLE=all` in production.
- Keep `session/` on persistent disk (already under `/opt/jiren-ads-bot/session`).
- Never commit `.env` or `session/` to GitHub.
- Rotate any tokens that were ever pasted in chat.
