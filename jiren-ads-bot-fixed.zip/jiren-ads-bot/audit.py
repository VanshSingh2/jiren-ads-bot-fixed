"""Admin audit log helpers (Mongo). Fail-soft: never raise into UI path."""
from __future__ import annotations
from datetime import datetime

def write_audit(col, actor_id, action: str, target_id=None, detail: str = ""):
    try:
        col.insert_one({
            'actor_id': int(actor_id) if actor_id is not None else None,
            'action': str(action)[:80],
            'target_id': int(target_id) if target_id is not None else None,
            'detail': str(detail)[:500],
            'at': datetime.utcnow(),
        })
    except Exception as e:
        print(f"[AUDIT] write failed: {e}")
