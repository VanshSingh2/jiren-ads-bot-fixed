"""Per-account temporary 'sick' cooldown after repeated flood hits."""
from __future__ import annotations
import time
from threading import Lock

_lock = Lock()
# account_id -> {'until': monotonic, 'hits': int, 'last': monotonic}
_state = {}

SICK_HITS = 3          # floods within window to mark sick
SICK_WINDOW = 900.0    # 15 min
SICK_COOLDOWN = 1800.0 # 30 min pause


def record_flood(account_id) -> bool:
    """Record a flood. Returns True if account is now (or still) sick."""
    aid = str(account_id)
    now = time.monotonic()
    with _lock:
        st = _state.get(aid) or {'hits': 0, 'last': 0.0, 'until': 0.0}
        if now - st['last'] > SICK_WINDOW:
            st['hits'] = 0
        st['hits'] += 1
        st['last'] = now
        if st['hits'] >= SICK_HITS:
            st['until'] = max(st.get('until', 0.0), now + SICK_COOLDOWN)
            st['hits'] = 0
        _state[aid] = st
        return st.get('until', 0.0) > now


def is_sick(account_id) -> float:
    """Seconds remaining sick, or 0."""
    aid = str(account_id)
    now = time.monotonic()
    with _lock:
        st = _state.get(aid)
        if not st:
            return 0.0
        left = st.get('until', 0.0) - now
        return left if left > 0 else 0.0


def clear(account_id):
    with _lock:
        _state.pop(str(account_id), None)
